main.py python执行脚本（所有的代码位置）
data_bookticket.xlsx 项目中各种表示和状态机的说明
data_train.xlsx 意图分类训练数据
stopword.txt 停用词
