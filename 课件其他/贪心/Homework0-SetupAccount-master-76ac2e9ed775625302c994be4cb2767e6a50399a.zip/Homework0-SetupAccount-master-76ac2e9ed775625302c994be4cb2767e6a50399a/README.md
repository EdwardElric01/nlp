作业：此次作业的主要目的是了解行业，了解技术以及搭建本地的gitlab环境。只需要在submit.md中填写要求的内容提交即可。

截止日期： <b>1月26日（本周六） 11：59PM<b>

提交作业:

1. 登录gitlab，fork一下本次项目到自己的gitlab里空间中
2. git clone 刚刚fork的项目到自己的本地
3. 按照要求修改submit.md文件
4. 提交submit.txt文件到自己的gitlab repo. 
5. 确保修改的文件已经在gitlab上展示

*note: <b>一定要先fork到自己空间! <b>

之后我们教学团队会逐个去每个人的空间去查看作业，并做评分。 